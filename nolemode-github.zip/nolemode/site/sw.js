// Nole Mode service worker: shows the reminders and handles their buttons.
const ART = {
  morning: { image: 'notif/morning.jpg', actions: [{ action: 'open', title: '☀️ Check in' }] },
  train:   { image: 'notif/train.jpg',   actions: [{ action: 'play', title: '▶ Start' }, { action: 'later', title: 'Later' }] },
  evening: { image: 'notif/evening.jpg', actions: [{ action: 'open', title: '🌙 Write' }] },
  press:   { image: 'notif/press.jpg',   actions: [{ action: 'open', title: '🎙 Open' }] },
  desk:    { image: 'notif/desk.jpg',    actions: [{ action: 'desk', title: '▶ Start break' }, { action: 'later', title: 'Later' }] },
  water:   { image: 'notif/water.jpg',   actions: [{ action: 'glass', title: '✓ +1 glass' }] },
  test:    { image: 'notif/train.jpg',   actions: [{ action: 'open', title: 'Open app' }] }
};
const today = () => { const d = new Date(); return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'); };

self.addEventListener('install', () => self.skipWaiting());
self.addEventListener('activate', e => e.waitUntil(self.clients.claim()));

self.addEventListener('push', e => {
  let d = {}; try { d = e.data.json(); } catch { d = { title: 'Nole Mode', body: e.data ? e.data.text() : '' }; }
  const kind = d.tag || 'test', art = ART[kind] || ART.test;
  e.waitUntil(self.registration.showNotification(d.title || 'Nole Mode', {
    body: d.body || '', icon: 'icon-192.png', badge: 'notif/badge.png', image: art.image,
    actions: art.actions, tag: kind, renotify: true, vibrate: [120, 60, 120], data: { tab: d.tab || 'day', kind }
  }));
});

// +1 glass is kept in a small cache queue; the app adds it to the day the next time it opens.
async function addGlass() {
  const c = await caches.open('nole-q'), key = '/q/glasses/' + today(), r = await c.match(key);
  const n = (r ? parseInt(await r.text(), 10) || 0 : 0) + 1;
  await c.put(key, new Response(String(n)));
}
async function openApp(msg) {
  const list = await self.clients.matchAll({ type: 'window', includeUncontrolled: true });
  for (const c of list) if ('focus' in c) { c.postMessage(msg); return c.focus(); }
  const q = new URLSearchParams({ tab: msg.tab }); if (msg.run) q.set('run', msg.run);
  return self.clients.openWindow(new URL('./?' + q, self.registration.scope).href);
}
self.addEventListener('notificationclick', e => {
  const data = e.notification.data || {};
  e.notification.close();
  if (e.action === 'later') return;
  if (e.action === 'glass') {
    e.waitUntil(addGlass().then(() => self.clients.matchAll({ type: 'window' })).then(list => list.forEach(c => c.postMessage({ glass: 1 }))));
    return;
  }
  const msg = e.action === 'play' ? { tab: 'home', run: 'play' } : e.action === 'desk' ? { tab: 'day', run: 'desk' } : { tab: data.tab || 'day' };
  e.waitUntil(openApp(msg));
});
