import { vapid, getSubs, send, json } from '../../lib/push.mjs';
export default async (req) => {
  let body; try { body = await req.json(); } catch { return json({ error: 'Send JSON.' }, 400); }
  await vapid();
  const sub = (await getSubs()).find(s => s.subscription.endpoint === body.endpoint);
  if (!sub) return json({ error: 'This device is not subscribed yet.' }, 404);
  const ok = await send(sub, { title: '🎾 Notifications are on', body: 'Game, set, match. Reminders will arrive here.', tab: 'day', tag: 'test' });
  return json({ ok });
};
export const config = { path: '/api/test' };
