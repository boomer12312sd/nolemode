import { getSubs, setSubs, json } from '../../lib/push.mjs';
import { DEFAULT_PREFS } from '../../lib/reminders.mjs';
export default async (req) => {
  let body; try { body = await req.json(); } catch { return json({ error: 'Send JSON.' }, 400); }
  const subs = await getSubs();
  if (req.method === 'DELETE') {
    await setSubs(subs.filter(s => s.subscription.endpoint !== body.endpoint));
    return json({ ok: true });
  }
  if (req.method !== 'POST' || !body.subscription || !body.subscription.endpoint) return json({ error: 'POST a subscription.' }, 400);
  const prefs = { ...DEFAULT_PREFS, ...(body.prefs || {}) };
  const rest = subs.filter(s => s.subscription.endpoint !== body.subscription.endpoint);
  rest.push({ subscription: body.subscription, prefs, updated: Date.now() });
  await setSubs(rest);
  return json({ ok: true, prefs });
};
export const config = { path: '/api/subscribe' };
