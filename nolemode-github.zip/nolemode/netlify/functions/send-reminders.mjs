import { vapid, getSubs, setSubs, send, store } from '../../lib/push.mjs';
import { slotOf, dueAt } from '../../lib/reminders.mjs';
// Runs every 30 minutes. Each half-hour slot is sent once, even if a run is late or repeated.
export default async () => {
  const slot = slotOf(new Date(Date.now() + 2 * 60 * 1000)); // a run at 07:59 still counts as 08:00
  const due = dueAt(slot);
  if (!due.length) return;
  const s = store();
  if ((await s.get('lastSlot')) === slot.key) return;
  await s.set('lastSlot', slot.key);
  await vapid();
  const subs = await getSubs(), keep = [];
  for (const sub of subs) {
    let alive = true;
    for (const r of due) if (sub.prefs[r.id] !== false) alive = (await send(sub, { title: r.title, body: r.body, tab: r.tab, tag: r.id })) && alive;
    if (alive) keep.push(sub);
  }
  if (keep.length !== subs.length) await setSubs(keep);
};
export const config = { schedule: '*/30 * * * *' };
