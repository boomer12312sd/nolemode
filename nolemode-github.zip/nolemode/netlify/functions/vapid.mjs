import { vapid, json } from '../../lib/push.mjs';
export default async () => json({ publicKey: (await vapid()).publicKey });
export const config = { path: '/api/vapid' };
