# Nole Mode

Personal training app (static page in `site/`) with push reminders sent by Netlify Functions.

- `site/` — the app, service worker (`sw.js`), manifest, icons and notification banners (`site/notif/`).
- `netlify/functions/` — `/api/vapid`, `/api/subscribe`, `/api/test`, and `send-reminders` (scheduled every 30 minutes).
- `lib/reminders.mjs` — the reminder schedule, in Europe/Rome time.

VAPID keys and subscriptions are stored in Netlify Blobs; nothing secret is in this repository.
